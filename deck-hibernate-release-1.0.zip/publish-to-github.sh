#!/usr/bin/env bash
set -Eeuo pipefail

OWNER="JosEffigy"
REPO="Deck-Hibernate"
FULL="$OWNER/$REPO"
DESCRIPTION="Suspend now, hibernate later for CachyOS handhelds with automatic swap, resume, initramfs, and bootloader detection."
DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

command -v gh >/dev/null 2>&1 || { echo "GitHub CLI (gh) is not installed." >&2; exit 1; }
gh auth status >/dev/null

# Ensure the release artifact has executable permissions in git.
chmod +x deck-hibernate.sh

if [[ ! -d .git ]]; then
    git init -b main
fi

git config user.name "$(gh api user --jq '.login')"
GH_ID="$(gh api user --jq '.id')"
GH_LOGIN="$(gh api user --jq '.login')"
git config user.email "${GH_ID}+${GH_LOGIN}@users.noreply.github.com"

git add README.md deck-hibernate.sh RELEASE_NOTES_release-1.0.md .gitignore
if ! git diff --cached --quiet; then
    git commit -m "release-1.0"
fi

if gh repo view "$FULL" >/dev/null 2>&1; then
    if ! git remote get-url origin >/dev/null 2>&1; then
        git remote add origin "https://github.com/$FULL.git"
    fi
    git push -u origin main
else
    gh repo create "$FULL" --public --description "$DESCRIPTION" --source=. --remote=origin --push
fi

gh repo edit "$FULL" --description "$DESCRIPTION"

if gh release view release-1.0 --repo "$FULL" >/dev/null 2>&1; then
    gh release upload release-1.0 deck-hibernate.sh --repo "$FULL" --clobber
else
    gh release create release-1.0 deck-hibernate.sh \
        --repo "$FULL" \
        --target main \
        --title "Deck-Hibernate release-1.0" \
        --notes-file RELEASE_NOTES_release-1.0.md \
        --latest
fi

printf 'Published: https://github.com/%s\n' "$FULL"
printf 'Release:   https://github.com/%s/releases/tag/release-1.0\n' "$FULL"
