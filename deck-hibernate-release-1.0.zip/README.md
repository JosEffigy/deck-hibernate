# Deck-Hibernate

Windows-handheld-style **suspend first, hibernate later** for CachyOS handhelds.

Deck-Hibernate configures Linux/systemd so a normal suspend request goes to RAM immediately, then automatically hibernates after a timer to reduce battery drain while the handheld is left asleep. The default delay is **15 minutes**, and the installer asks for a different delay after sudo authentication.

## Quick install

Copy and paste this into a terminal:

```bash
tmp="$(mktemp --suffix=.sh)" && curl -fsSL https://raw.githubusercontent.com/JosEffigy/Deck-Hibernate/main/deck-hibernate.sh -o "$tmp" && chmod +x "$tmp" && "$tmp"; rc=$?; rm -f "$tmp"; exit $rc
```

The script intentionally downloads to a temporary file instead of using `curl | bash`, because it re-launches its own file through `sudo`.

### What you will be asked

1. Your sudo password. Deck-Hibernate deliberately invalidates cached sudo credentials first so a normal-user launch asks at the start.
2. `Minutes before hibernating [15]:` — press **Enter** for 15 minutes.
3. On success: `Successful, please restart system. Press any key to close.`

Everything else is detected automatically or the installer aborts safely if it cannot determine a supported configuration.

## What it detects

- Existing persistent swap partitions or swapfiles.
- Optional zram. **zram is not required** and Deck-Hibernate does not assume `/dev/zram0` or a zram directory exists.
- Root filesystem and whether a hibernation swapfile can be safely created.
- Btrfs swapfile resume offsets using `btrfs inspect-internal map-swapfile`.
- Regular swapfile resume offsets using `filefrag` where applicable.
- mkinitcpio and dracut initramfs setups.
- CachyOS Limine / `limine-mkinitcpio`, systemd-boot / `sdboot-manage`, GRUB, and rEFInd boot setups.
- Kernel suspend and hibernation availability before making the sleep configuration active.

It backs up configuration files that it changes and does **not** repartition disks.

## Compatibility disclosure

### Handhelds

**Primary target:** CachyOS Handheld Edition / Deckify installations.

CachyOS currently documents device-specific/official support for these handheld families:

- **Valve Steam Deck** — including the CachyOS kernel/firmware work for Deck OLED.
- **ASUS ROG Ally family** — CachyOS provides Ally-specific kernel and handheld handling; current CachyOS handheld releases also contain Ally/Ally X-specific fixes.
- **Lenovo Legion Go family** — CachyOS uses Handheld Daemon for its handheld integration.

Deck-Hibernate itself does not contain device-specific controller code. It changes the OS sleep path beneath Steam/Game Mode/KDE, so compatible handhelds can use the same suspend-then-hibernate setup.

Other handheld PCs — AYANEO, OneXPlayer, AOKZOE, MSI Claw, GPD, and similar devices — **may work if their Linux firmware/kernel sleep and hibernation support is functional**, but they are not claimed as tested or officially supported by this project.

CachyOS notes that unknown/non-official handheld hardware can have device-specific issues such as audio, orientation, controller, or power-management behavior.

### Linux distributions

| Distribution | release-1.0 status |
| --- | --- |
| **CachyOS Handheld Edition / Deckify** | **Primary supported target** |
| **CachyOS desktop** | Expected to work when using one of the detected boot/initramfs configurations |
| **Arch Linux** | Best-effort supported; the script explicitly accepts `ID=arch` |
| EndeavourOS / Garuda / Manjaro / other Arch derivatives | **Not claimed in release-1.0**; their distro IDs and boot tooling can differ |
| SteamOS | **Not supported in release-1.0** |
| Bazzite / Fedora Atomic | **Not supported in release-1.0** |
| Fedora / Nobara | **Not supported in release-1.0** |
| Ubuntu / Debian / Linux Mint | **Not supported in release-1.0** |
| ChimeraOS | **Not supported in release-1.0** |

The underlying systemd feature is portable, but this installer also modifies swap, initramfs, and boot configuration. Those distro-specific parts are why the project does not claim universal Linux compatibility.

### Filesystems and swap

Deck-Hibernate prefers an already-existing persistent swap area when it is large enough. In that case, the root filesystem is much less important.

When it must create its own hibernation swapfile, release-1.0 has explicit automatic handling for:

- **Btrfs**
- **XFS**
- **ext2 / ext3 / ext4**
- **F2FS**

For **ZFS** and **bcachefs**, Deck-Hibernate will not invent a filesystem-backed hibernation swapfile. If a suitable persistent swap block device/partition already exists, it can use that; otherwise it aborts rather than repartitioning the drive or guessing. Bcachefs upstream still lists swap-file support as future work, and ZFS requires special handling that is not safe to generalize into an unattended installer.

For an unrecognized filesystem, the project does not claim that automatically creating a hibernation swapfile is safe. An existing suitable swap device remains the preferred route.

### Initramfs / boot configuration

**Handled:**

- mkinitcpio
- mkinitcpio with the `systemd` hook
- dracut
- CachyOS Limine with `limine-mkinitcpio`
- systemd-boot using CachyOS `sdboot-manage`
- GRUB
- rEFInd

**Detected but intentionally not auto-configured:**

- Booster — release-1.0 aborts instead of guessing at a hibernation integration path.

If the script cannot confidently identify the required path, it exits and leaves the risky step undone.

## SSD wear

Hibernation cannot be completely write-free: the memory snapshot must be written to persistent storage. Deck-Hibernate minimizes unnecessary writes by:

- Staying in RAM suspend first, so short sleep/wake sessions never hibernate.
- Keeping existing zram available for ordinary swapping instead of replacing it.
- Setting a reduced hibernation image-size target (30% of RAM) to reduce the amount that normally needs to be written.
- Using persistent disk swap only when hibernation actually requires it.

Modern SSDs are designed for substantial write workloads, but this project does not claim zero wear.

## Vibe-coded / AI disclosure

**This project is vibe-coded and was created with substantial AI assistance (ChatGPT).**

The script has been reviewed for obvious destructive behavior and uses conservative abort paths, but it has **not** been exhaustively tested across every handheld, filesystem, encryption layout, bootloader, initramfs generator, kernel, firmware revision, or dual-boot arrangement.

This script modifies low-level system configuration including swap, `/etc/fstab`, kernel resume parameters, initramfs configuration, boot-manager configuration, and systemd sleep services. Review the script and keep backups of important data before running it. Use it at your own risk.

## release-1.0

The first release includes `deck-hibernate.sh` as a downloadable release asset.

Pinned release launcher, once `release-1.0` is published:

```bash
tmp="$(mktemp --suffix=.sh)" && curl -fsSL https://github.com/JosEffigy/Deck-Hibernate/releases/download/release-1.0/deck-hibernate.sh -o "$tmp" && chmod +x "$tmp" && "$tmp"; rc=$?; rm -f "$tmp"; exit $rc
```

## References

- CachyOS Handheld Edition: https://wiki.cachyos.org/installation/installation_handheld/
- CachyOS Handheld repository/device notes: https://github.com/CachyOS/CachyOS-Handheld
- systemd suspend-then-hibernate / `HibernateDelaySec=`: https://man.archlinux.org/man/systemd-sleep.conf.5.en
- Linux kernel hibernation/resume documentation: https://docs.kernel.org/power/swsusp.html
- util-linux swapfile documentation: https://man.archlinux.org/man/mkswap.8.en
- bcachefs project wishlist (swap-file support): https://bcachefs.org/Wishlist/
