# Deck-Hibernate release-1.0

Initial public release of Deck-Hibernate.

## Highlights

- Turns ordinary suspend into systemd `suspend-then-hibernate` behavior.
- Requests sudo authentication immediately, then asks for the sleep-before-hibernate timer; Enter defaults to 15 minutes.
- Detects existing persistent swap without assuming zram exists.
- Preserves zram when present.
- Supports managed swapfile creation on Btrfs, XFS, ext2/ext3/ext4, and F2FS when required and safe.
- Uses existing persistent swap devices for filesystems where unattended swapfile creation is not supported, including ZFS/bcachefs scenarios.
- Handles Btrfs-specific resume offsets.
- Detects mkinitcpio and dracut.
- Handles CachyOS Limine/`limine-mkinitcpio`, systemd-boot/`sdboot-manage`, GRUB, and rEFInd.
- Refuses Booster and unknown critical configurations rather than guessing.
- Backs up files it changes and does not repartition disks.
- Reduces the kernel hibernation image-size target to limit unnecessary SSD writes.

## Compatibility

Primary target: CachyOS Handheld Edition / Deckify on CachyOS-supported Steam Deck, ASUS ROG Ally-family, and Lenovo Legion Go-family handhelds. Arch Linux is best-effort supported. Other major distributions are not claimed for release-1.0.

See the README for the full filesystem, initramfs, boot-manager, handheld, and distro compatibility disclosure.

## Vibe-coded disclosure

This project was vibe-coded with substantial AI assistance (ChatGPT). It has not been exhaustively tested across every hardware and installation combination. The script changes low-level boot, swap, initramfs, and sleep configuration; review it and keep backups before use.

## Release asset

- `deck-hibernate.sh`
